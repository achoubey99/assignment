#ifndef DATE_H__
#define DATE_H__

#include <string.h>
using namespace std;

class Date {
    private: 
          int day, month, year;    // instance variable
    public:
          Date();
          Date(int d);
          Date(int d, int m, int y);
          int getYear();
          void setDate(int day, int month, int year);
          void getDate();
          string getMonthName();
          bool checkLeapYear();
		  };
#endif

